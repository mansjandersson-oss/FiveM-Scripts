Config = {}

Config.Debug = false
Config.Locale = 'en'

Config.Security = {
    ValidateDistance = true,
    MaxHarvestDistance = 6.0,
    MaxProcessDistance = 8.0,
    MaxStockDistance = 6.0
}

Config.PoliceRequired = 0

Config.PoliceAlert = {
    Enabled = true,
    PermitItem = 'destileringstillstand',
    Dispatch = {
        Resource = 'lb-tablet',
        UseFallbackNotify = true,
        Code = '10-66',
        Priority = 'medium',
        Title = 'Misstänkt hembränning',
        LocationLabel = 'Hembränningsapparat',
        Time = 300,
        Sound = 'notification.mp3'
    },
    PoliceJobs = {
        police = true
    },
    Actions = {
        ferment = true,
        distill = true,
        bottle = true,
        pack = true
    },
    Cooldown = 120,
    Witness = {
        Radius = 25.0,
        Fov = 100.0,
        RequireLineOfSight = true
    },
    Blip = {
        Enabled = true,
        Sprite = 161,
        Color = 1,
        Scale = 1.0,
        Duration = 60
    }
}

Config.MinDeliveryPayout = 420
Config.MaxDeliveryPayout = 780

Config.Progress = {
    Harvest = 5500,
    Ferment = 9000,
    Distill = 10500,
    Bottle = 6000,
    Pack = 5000,
    Stock = 6500
}

Config.Cooldowns = {
    Harvest = 20,
    Process = 3,
    Delivery = 10
}

Config.Items = {
    grape = 'grape',
    barley = 'barley',
    yeast = 'yeast',
    springWater = 'spring_water',
    wineMash = 'wine_mash',
    beerMash = 'beer_mash',
    distilledSpirit = 'distilled_spirit',
    emptyBottle = 'empty_bottle',
    cardboard = 'cardboard',
    bottledLiquor = 'bottled_liquor',
    liquorCrate = 'liquor_crate'
}

Config.Products = {
    wine = 'product_wine',
    beer = 'product_beer',
    vodka = 'product_vodka',
    gin = 'product_gin',
    whiskey = 'product_whiskey'
}

Config.Minigames = {
    Harvest = {
        stages = { 'easy', 'easy' },
        keys = { 'w', 'a', 's', 'd' }
    },
    Ferment = {
        stages = { 'easy', 'medium', 'medium' },
        keys = { 'w', 'a', 's', 'd' },
        tempMin = 18,
        tempMax = 30,
        sweetSpotVariance = 1,
        stirMin = 1,
        stirMax = 5,
        explosionChance = 35,
        explosionRadius = 5.0,
        explosionDamage = 50
    },
    Distill = {
        stages = { 'medium', 'medium', 'hard' },
        keys = { 'w', 'a', 's', 'd' },
        tempMin = 60,
        tempMax = 100,
        timeMin = 20,
        timeMax = 140
    },
    Bottle = {
        stages = { 'easy', 'medium', 'hard' },
        keys = { 'q', 'e', 'a', 'd' }
    },
    Pack = {
        stages = { 'medium', 'hard', 'hard' },
        keys = { 'q', 'e', 'a', 'd' },
        breakMin = 1,
        breakMax = 2
    },
    Stock = {
        stages = { 'easy', 'medium' },
        keys = { 'w', 'a', 's', 'd' }
    }
}

Config.FermentationRoutes = {
    wine = {
        labelKey = 'route_wine_mash',
        output = Config.Items.wineMash,
        outputCount = 2,
        input = {
            [Config.Items.grape] = 4,
            [Config.Items.yeast] = 1,
            [Config.Items.springWater] = 1
        }
    },
    beer = {
        labelKey = 'route_beer_mash',
        output = Config.Items.beerMash,
        outputCount = 2,
        input = {
            [Config.Items.barley] = 4,
            [Config.Items.yeast] = 1,
            [Config.Items.springWater] = 1
        }
    }
}

Config.DistillProfiles = {
    beer = {
        whiskey = {
            labelKey = Config.Products.whiskey,
            temp = { min = 74, max = 83 },
            time = { min = 60, max = 95 },
            purity = { min = 82, max = 94 }
        },
        vodka = {
            labelKey = Config.Products.vodka,
            temp = { min = 84, max = 96 },
            time = { min = 45, max = 75 },
            purity = { min = 88, max = 99 }
        },
        gin = {
            labelKey = Config.Products.gin,
            temp = { min = 68, max = 78 },
            time = { min = 80, max = 120 },
            purity = { min = 75, max = 90 }
        },
        beer = {
            labelKey = Config.Products.beer,
            temp = { min = 60, max = 72 },
            time = { min = 25, max = 55 },
            purity = { min = 70, max = 82 }
        }
    },
    wine = {
        wine = {
            labelKey = Config.Products.wine,
            temp = { min = 65, max = 86 },
            time = { min = 35, max = 90 },
            purity = { min = 72, max = 88 }
        }
    }
}


Config.Recipes = {
    Bottle = {
        input = {
            [Config.Items.distilledSpirit] = 1,
            [Config.Items.emptyBottle] = 1
        },
        output = {
            item = Config.Items.bottledLiquor,
            count = 1
        }
    },
    Pack = {
        input = {
            [Config.Items.bottledLiquor] = 6,
            [Config.Items.cardboard] = 1
        },
        output = {
            item = Config.Items.liquorCrate,
            count = 1
        }
    }
}

Config.HarvestZones = {
    {
        name = 'grape_harvest',
        labelKey = 'zone_harvest_grapes',
        icon = 'fa-solid fa-seedling',
        item = Config.Items.grape,
        count = { min = 2, max = 4 },
        coords = vec3(-1886.68, 2101.8, 140.98),
        size = vec3(2.0, 2.0, 2.0),
        rotation = 330.0
    },
    {
        name = 'barley_harvest',
        labelKey = 'zone_harvest_barley',
        icon = 'fa-solid fa-wheat-awn',
        item = Config.Items.barley,
        count = { min = 1, max = 3 },
        coords = vec3(2306.8, 5130.59, 50.44),
        size = vec3(2.2, 2.2, 2.2),
        rotation = 315.0
    },
    {
        name = 'spring_water_collect',
        labelKey = 'zone_collect_water',
        icon = 'fa-solid fa-droplet',
        item = Config.Items.springWater,
        count = { min = 1, max = 2 },
        coords = vec3(1658.85, -26.42, 173.78),
        size = vec3(2.0, 2.0, 2.0),
        rotation = 350.0
    },
    {
        name = 'yeast_supply',
        labelKey = 'zone_collect_yeast',
        icon = 'fa-solid fa-box-open',
        item = Config.Items.yeast,
        count = { min = 1, max = 2 },
        coords = vec3(-102.51, 6208.35, 31.03),
        size = vec3(2.5, 2.5, 2.5),
        rotation = 45.0
    },
    {
        name = 'bottle_supply',
        labelKey = 'zone_collect_bottles',
        icon = 'fa-solid fa-wine-bottle',
        item = Config.Items.emptyBottle,
        count = { min = 2, max = 4 },
        coords = vec3(2743.4, 3471.75, 55.67),
        size = vec3(2.5, 2.5, 2.5),
        rotation = 250.0
    },
    {
        name = 'cardboard_supply',
        labelKey = 'zone_collect_cardboard',
        icon = 'fa-solid fa-box',
        item = Config.Items.cardboard,
        count = { min = 1, max = 2 },
        coords = vec3(145.58, -3093.85, 5.9),
        size = vec3(2.8, 2.8, 2.8),
        rotation = 90.0
    }
}

Config.ProcessingStations = {
    {
        name = 'fermentation_vat',
        labelKey = 'zone_start_fermentation',
        action = 'ferment',
        icon = 'fa-solid fa-vial-circle-check',
        coords = vec3(1980.91, 3052.36, 47.22),
        size = vec3(2.0, 2.0, 2.0),
        rotation = 60.0
    },
    {
        name = 'distillery_station',
        labelKey = 'zone_run_distillery',
        action = 'distill',
        icon = 'fa-solid fa-fire-burner',
        coords = vec3(1983.35, 3055.81, 47.22),
        size = vec3(2.2, 2.2, 2.2),
        rotation = 300.0
    },
    {
        name = 'bottling_line',
        labelKey = 'zone_bottle_liquor',
        action = 'bottle',
        icon = 'fa-solid fa-bottle-droplet',
        coords = vec3(1986.34, 3051.98, 47.22),
        size = vec3(2.0, 2.0, 2.0),
        rotation = 30.0
    },
    {
        name = 'packing_table',
        labelKey = 'zone_pack_crate',
        action = 'pack',
        icon = 'fa-solid fa-boxes-packing',
        coords = vec3(1988.83, 3048.32, 47.22),
        size = vec3(2.2, 2.2, 2.0),
        rotation = 340.0
    }
}

Config.StockZones = {
    {
        name = 'downtown_liquor_stock',
        labelKey = 'zone_stock_downtown',
        icon = 'fa-solid fa-store',
        coords = vec3(-1222.2, -906.75, 12.33),
        size = vec3(1.8, 1.8, 2.0),
        rotation = 30.0
    },
    {
        name = 'sandy_liquor_stock',
        labelKey = 'zone_stock_sandy',
        icon = 'fa-solid fa-store',
        coords = vec3(1393.12, 3605.16, 34.98),
        size = vec3(1.8, 1.8, 2.0),
        rotation = 20.0
    },
    {
        name = 'vespucci_liquor_stock',
        labelKey = 'zone_stock_vespucci',
        icon = 'fa-solid fa-store',
        coords = vec3(-2966.51, 391.2, 15.04),
        size = vec3(1.8, 1.8, 2.0),
        rotation = 355.0
    }
}

Config.Blips = {
    { enabled = true, labelKey = 'blip_booze_farm',   sprite = 469, color = 25, scale = 0.8, coords = vec3(-1886.68, 2101.8, 140.98) },
    { enabled = true, labelKey = 'blip_distillery',   sprite = 93,  color = 47, scale = 0.8, coords = vec3(1983.35, 3055.81, 47.22)  },
    { enabled = true, labelKey = 'blip_distribution', sprite = 478, color = 17, scale = 0.8, coords = vec3(-1222.2, -906.75, 12.33)  }
}
